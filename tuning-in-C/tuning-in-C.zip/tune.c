// TODO: Write the code to complete the twelve_TET_octave function.

#include <math.h>

#define OCTAVE_WIDTH 12 // the number of notes in one octave

/**
 * @brief This function computes a single octave of notes using the twelve-tone
 * equal temperament tuning system and stores the frequencies of each note in
 * the array passed as a parameter. The octave begins at the root passed in.
 * 
 * The length of the array is 13, meaning that the root note appears twice:
 * once at the start and once at the end. The first element in the array (i.e.
 * octave_arr[0]) should be equal to root. The last element in the array (i.e.
 * octave_arr[13], aka octave_arr[OCTAVE_WIDTH + 1]) should be the note one
 * octave above root, i.e. twice the value of root.
 * 
 * @param root a frequency representing the root note at which the octave
 *        should begin. root must be a valid frequency, i.e. greater than 0.
 * 
 * @param octave_arr a pointer to an array of length 13 which will be populated
 *        by this function.
 * 
 * @return int status code. Success is indicated by 0, and failures are
 * indicated by positive return values. The function should detect when
 * invalid values for parameters have been passed. In particular:
 * 
 *       return | meaning
 *       -------|------------
 *          0   | success
 *          1   | failure: the value of root is not a valid frequency
 */
int twelve_TET_octave(double root, double *octave_arr) {

   //  TODO: YOUR CODE HERE
   //    your job is to populate octave_arr.
   //    don't forget to return a status code.
   
}
#ifndef TET_H
#define TET_H

/**
 * @brief Computes one octave of twelve-tone equally tempered notes starting
 * at the root note passed in.
 * 
 * @return int status code
 */
int twelve_TET_octave(double, double*);

#endif
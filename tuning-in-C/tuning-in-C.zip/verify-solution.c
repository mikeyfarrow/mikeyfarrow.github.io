// This program is used to test your code. There is nothing required
// for you to do inside this file, though it may be a good idea to read and
// understand what it does.

#include <stdio.h>
#include <math.h>
#include "tune.h"

#define OCTAVE_WIDTH 12

// these extra parameters to main allow us to process "command line arguments".
int main( int argc, char *argv[] )
{
   // allocate an array for an octave
   double notes[OCTAVE_WIDTH + 1];

   // by default use A3 for root note
   double note = 220.0;
   
   // if a command line argument has been passed, use that for root instead
   if (argc == 2)
      sscanf(argv[1], "%lf", &note);
   else
      printf("No command line argument was provided, so we use A3\n");
   

   printf("Requesting an octave beginning at %.2f\n", note);

   int status = twelve_TET_octave(note, notes);

   // check the status code
   if (status == 1) {
      printf("oh no, someone passed an invalid frequency\n");
      return 1; // bail now if there was an error
   }

   // Print out the values in the array so we can see the frequencies
   for (int i = 0; i <= OCTAVE_WIDTH; i++) {
      printf("%.2f\n", notes[i]);
   }

   return 0;
}